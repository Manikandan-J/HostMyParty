import { Component, OnInit } from '@angular/core';
import { DataService } from '../Service/data.service';
import { Router } from '@angular/router';
import { UserService } from '../Service/user.service';
import { User } from '../Model/User';

@Component({
  selector: 'app-main-template',
  templateUrl: './main-template.component.html',
  styleUrls: ['./main-template.component.css']
})
export class MainTemplateComponent implements OnInit {
  role: string; 
  email: string;
  user: User;
  name: string;
 
  service:Boolean = false;
  constructor(private dataService: DataService,private router: Router,private userService: UserService) { }
  
  
  ngOnInit(): void {
     
    this.dataService.currentUserEmail.subscribe(email => this.email = email);
    this.dataService.currentRole.subscribe(role => this.role =role);
    
    if(this.role !='User')
    {
      this.service = true;
    }
    
      this.userService.getUserDataByEmail(this.email).subscribe(userData => this.user = userData);
      
       
    
  }
  

}
