import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { HttpClientModule } from '@angular/common/http';

import { MainTemplateComponent } from './main-template/main-template.component';
import { InfoComponent } from './Common/info/info.component';
import { RandomPartiesComponent } from './Common/random-parties/random-parties.component';
import { RegisterProfileComponent } from './Common/register-profile/register-profile.component';
import { VendorServiceComponent } from './Vendor/vendor-service/vendor-service.component';
import { EventManagerComponent } from './Vendor/event-manager/event-manager.component';
import { PhotoVideoGraphyComponent } from './Vendor/photo-video-graphy/photo-video-graphy.component';
import { BakeryComponent } from './Vendor/bakery/bakery.component';
import { FoodChefComponent } from './Vendor/food-chef/food-chef.component';
import { PerformerComponent } from './Vendor/performer/performer.component';
import { HallsComponent } from './Vendor/halls/halls.component';
import { UpdateHallInfoComponent } from './Vendor/UpdateVendorInfo/update-hall-info/update-hall-info.component';
import { UpdateBakeryInfoComponent } from './Vendor/UpdateVendorInfo/update-bakery-info/update-bakery-info.component';
import { UpdateEventManagerInfoComponent } from './Vendor/UpdateVendorInfo/update-event-manager-info/update-event-manager-info.component';
import { UpdateFoodChefInfoComponent } from './Vendor/UpdateVendorInfo/update-food-chef-info/update-food-chef-info.component';
import { UpdatePerformerInfoComponent } from './Vendor/UpdateVendorInfo/update-performer-info/update-performer-info.component';
import { UpdatePhotoVideoGraphyInfoComponent } from './Vendor/UpdateVendorInfo/update-photo-video-graphy-info/update-photo-video-graphy-info.component';
import { SearchComponent } from './Common/search/search.component';
import { UpdateStatusComponent } from './Common/update-status/update-status.component';
import { BookVendorComponent } from './Common/book-vendor/book-vendor.component';
import { NotificationComponent } from './Common/notification/notification.component';
import { HistoryComponent } from './Common/history/history.component';
import { WalletComponent } from './Common/wallet/wallet.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
   
    MainTemplateComponent,
    
    InfoComponent,
    
    RandomPartiesComponent,
    
    RegisterProfileComponent,
    
    VendorServiceComponent,
    
    EventManagerComponent,
    
    PhotoVideoGraphyComponent,
    
    BakeryComponent,
    
    FoodChefComponent,
    
    PerformerComponent,
    
    HallsComponent,
    
    UpdateHallInfoComponent,
    
    UpdateBakeryInfoComponent,
    
    UpdateEventManagerInfoComponent,
    
    UpdateFoodChefInfoComponent,
    
    UpdatePerformerInfoComponent,
    
    UpdatePhotoVideoGraphyInfoComponent,
    
    SearchComponent,
    
    UpdateStatusComponent,
    
    BookVendorComponent,
    
    NotificationComponent,
    
    HistoryComponent,
    
    WalletComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
