import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  baseUrl = 'http://localhost:8085/VendorsInfo';
  constructor(private http: HttpClient) { }
  updateBooking(bookingData: Object):Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/updateBookingTable/`,bookingData);
  }
  
}
