import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Search } from '../Model/Search';

@Injectable({
  providedIn: 'root'
})
export class SearchServiceService {
 
  baseUrl = 'http://localhost:8085/VendorsInfo';
  constructor(private http: HttpClient) { }
  updateSearch(searchData: Object): Observable<Object> {
     
    return this.http.post(`${this.baseUrl}`+`/updateSearch`,searchData);

  }
  getAllSearchData(email: string): Observable<any>
  {
    return this.http.get(`${this.baseUrl}/getAllSearchData/${email}`);

  }
  getSearchFilterData(role: string,location: string):Observable<any>
  {
    return this.http.get<any>(`${this.baseUrl}/getFilterData/${role}/${location}`);
  }
  getFilterDataByRole(role: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/getFilterDataByRole/${role}`);
  }
  getFilterDataByLocation(location: string):Observable<any> {
    return this.http.get(`${this.baseUrl}/getFilterDataByLocation/${location}`);
    }
 

}
