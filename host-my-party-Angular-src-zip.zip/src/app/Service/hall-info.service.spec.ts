import { TestBed } from '@angular/core/testing';

import { HallInfoService } from './hall-info.service';

describe('HallInfoService', () => {
  let service: HallInfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HallInfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
