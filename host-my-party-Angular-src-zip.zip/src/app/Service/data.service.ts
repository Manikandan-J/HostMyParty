import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from '../Model/User';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  // data service for getting/seting role data
  private role = new BehaviorSubject('null');
  currentRole = this.role.asObservable();
  
  setRole(role: string) {
    this.role.next(role);
  }

  // data service for getting/seting email data
  private email = new BehaviorSubject('null@gmail.com');
  currentUserEmail = this.email.asObservable();
  setEmail(email: string)
  {
    this.email.next(email);
  }

  //StoreUserData
  private user = new BehaviorSubject(null);
  currentUser = this.user.asObservable();
  setUser(user: User)
  {
    this.user.next(user);
  }
    constructor() { }

 
}
