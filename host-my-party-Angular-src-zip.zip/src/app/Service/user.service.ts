import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../Model/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl = 'http://localhost:8085/user';
  constructor(private http: HttpClient) { }
  getUserDataByEmail(email: string): Observable<any>
  {
    return this.http.get(`${this.baseUrl}/getByEmail/${email}`);

  }
  
  registerUser(user: Object): Observable<Object> {
     
    return this.http.post(`${this.baseUrl}`+`/registerProfile`,user);

  }
  addAmountInWallet(wallet: Object): Observable<Object> {
     
    return this.http.post(`${this.baseUrl}`+`/addAmount`,wallet);

  }
  bookVendor(bookingData: Object): Observable<Object> {
     
    
    return this.http.post(`${this.baseUrl}`+`/bookVendor`,bookingData);

  }
  getAllBookingRecords(): Observable<any>
  {
    return this.http.get<any>(`${this.baseUrl}/getAllBookingRecords`);
  }

}
