import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HallInfoService {
  baseUrl = 'http://localhost:8085/VendorsInfo';
  constructor(private http: HttpClient) { }
  getHallInfo(email: string):Observable<any>
  {
    return this.http.get(`${this.baseUrl}/getHallInfo/${email}`);
  }

  updateHallInfo(hallInfo: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/updateHallInfo`,hallInfo);

  }
}
