import { Component, OnInit } from '@angular/core';
import { Login } from '../Model/Login';
import { LoginServicesService } from '../Service/login-services.service';
import { Router } from '@angular/router';
import { DataService } from '../Service/data.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  email:string;
  password: string; 
  role: string;
  invalidLogin: boolean = false;
  login: Login[];
  invalidCredential: boolean =false;
   
 
  constructor(private router: Router,private loginService: LoginServicesService,private dataService: DataService) { }

  ngOnInit(): void {
    this.loginService.getCredentials().subscribe(data => this.login = data);

  }
  checkCredentials()
  {
           for(let i=0;i<this.login.length;i++)
           {
             if(this.email==this.login[i].email&&this.password==this.login[i].password)
             {
              console.log(this.login[0].email,this.login[0].password,this.login[0].role)
              this.dataService.setEmail(this.login[i].email);
              this.dataService.setRole(this.login[i].role);
              this.router.navigate(['MainAction']);
             }
             else{
                   this.invalidCredential =true;
             }
           }
  }
  onSubmit()
  {
      
     this.checkCredentials();
  }

}
