export class Hall {
    email: string;
    hallName: string;
    hallRole: String;
    noOfFloor: number;
    dimension: string;
    peopleCount: number;
    dinningStyle: string;
    ratePerHour: number;
    location: string;
 
    constructor(email,hallName,hallRole,noOfFloor,dimension,peopleCount,dinningStyle,ratePerHour,location) {
        this.email = email;
        this.hallName = hallName;
        this.hallRole = hallRole;
        this.noOfFloor = noOfFloor;
        this.dimension = dimension;
        this.peopleCount = peopleCount;
        this.dinningStyle = dinningStyle;
        this.ratePerHour = ratePerHour;
        this.location = location;
        
    }
}