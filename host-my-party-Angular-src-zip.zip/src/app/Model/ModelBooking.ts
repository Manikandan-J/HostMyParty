export class ModelBooking
{
    bookingId: number;
    userEmail: string;
    vendorEmail: string;
    bookingDate: string;
    bookingStatus: string;
    constructor(bookingId, userEmail,vendorEmail,bookingDate,bookingStatus)
    {
        this.bookingId = bookingId;
        this.userEmail = userEmail;
        this.vendorEmail = vendorEmail;
        this.bookingDate = bookingDate;
        this.bookingStatus = bookingStatus;
        

    }
}