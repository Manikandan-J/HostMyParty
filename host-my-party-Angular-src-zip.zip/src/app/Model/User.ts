export class User
{
    email: string;
    name: string;
    gender: string;
    role: string;
    password: string;
    address: string;
    city:string;
    number: string;
    constructor(email,name,gender,role,password,address,city,number)
    {
        this.email = email;
        this.name = name;
        this.gender = gender;
        this.role = role;
        this.password = password;
        this.address =address;
        this.city=city;
        this.number = number;
    }
}