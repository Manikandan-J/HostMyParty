
export class Search
{
    email: string;
    role: string;
    location: string;
    status: string;
    constructor(email,role,location,status)
    {
        this.email =email;
        this.role= role;
        this.location= location;
        this.status=status;
    }
}