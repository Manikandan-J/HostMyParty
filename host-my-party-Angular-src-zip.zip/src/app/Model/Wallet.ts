export class  Wallet
{
 email: string;
 amount: string;
 constructor(email,amount)
 {
     this.email = email;
     this.amount = amount;
 }
}