export class Booking
{
    bookingId: number;
    userEmail: string;
    vendorEmail: string;
    bookingDate: string;
    bookingStatus: string;
    constructor(userEmail,vendorEmail,bookingDate,bookingStatus)
    {
        this.userEmail = userEmail;
        this.vendorEmail = vendorEmail;
        this.bookingDate = bookingDate;
        this.bookingStatus = bookingStatus;
        

    }
}