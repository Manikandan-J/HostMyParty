import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/Service/data.service';
import { UserService } from 'src/app/Service/user.service';
import { Wallet } from 'src/app/Model/Wallet';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {

  amount: string;
  email: string;
  success: boolean= false;
  constructor(private dataService: DataService,private walletService: UserService) { }

  ngOnInit(): void {
    this.dataService.currentUserEmail.subscribe(email => this.email = email);

  }
  addWallet()
  {
    this.success = true;
    let money =new  Wallet(this.email,this.amount);
    this.walletService.addAmountInWallet(money).subscribe(response=>console.log(response));
  }

}
