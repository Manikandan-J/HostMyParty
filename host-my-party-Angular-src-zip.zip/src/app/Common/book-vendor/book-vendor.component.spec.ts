import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookVendorComponent } from './book-vendor.component';

describe('BookVendorComponent', () => {
  let component: BookVendorComponent;
  let fixture: ComponentFixture<BookVendorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookVendorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookVendorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
