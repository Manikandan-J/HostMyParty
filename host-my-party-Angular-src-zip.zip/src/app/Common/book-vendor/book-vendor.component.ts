import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-vendor',
  templateUrl: './book-vendor.component.html',
  styleUrls: ['./book-vendor.component.css']
})
export class BookVendorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
