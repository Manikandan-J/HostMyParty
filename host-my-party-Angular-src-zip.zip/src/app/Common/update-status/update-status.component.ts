import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/Service/data.service';
import { SearchServiceService } from 'src/app/Service/search-service.service';
import { Search } from 'src/app/Model/Search';

@Component({
  selector: 'app-update-status',
  templateUrl: './update-status.component.html',
  styleUrls: ['./update-status.component.css']
})
export class UpdateStatusComponent implements OnInit {

  status: string;
  email: string;
  role: string;
  location: string;
  search: Search;
  constructor(private dataService: DataService,private searchService: SearchServiceService) { }

  ngOnInit(): void {
    this.dataService.currentUserEmail.subscribe(email => this.email = email);
    this.searchService.getAllSearchData(this.email).subscribe(allSearchData => this.search =allSearchData);
    this.role = this.search.role;
    this.location = this.location;

  }
  onSubmit()
  {
    let newSearchData = new  Search(this.email,this.role,this.location,this.status);
    this.searchService.updateSearch(newSearchData).subscribe(response => console.log(response));
  }

}
