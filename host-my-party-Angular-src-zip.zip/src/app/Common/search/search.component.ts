import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from 'src/app/Service/search-service.service';
import { Router } from '@angular/router';
import { Search } from 'src/app/Model/Search';
import { DataService } from 'src/app/Service/data.service';
import { UserService } from 'src/app/Service/user.service';
import { BookVendorComponent } from '../book-vendor/book-vendor.component';
import { Booking } from 'src/app/Model/Booking';
import { Hall } from 'src/app/Model/Hall';
import { HallInfoService } from 'src/app/Service/hall-info.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

   email: string;
    role: string;
    location: string;
    date: string;
    display: boolean =false;
    cont: boolean = true;
    success: boolean =false;
    isrole :boolean =true;
  constructor(private router: Router,private filterService: SearchServiceService,private dataService:DataService,private userService: UserService,private hallService: HallInfoService) { }
   search: Search[];
   vendorEmail: string;
   hallInfo: Hall;
   vendorRole: string;
   bookFormOpen: boolean =false;
   bookFormClose: boolean =true;
   hideVendorProfile: boolean = true;
  ngOnInit(): void {
    this.dataService.currentUserEmail.subscribe(email => this.email = email);

  }

  onSubmit()
  {
       if(this.role!=null && this.location !=null)
       {
       this.filterService.getSearchFilterData(this.role,this.location).subscribe(response => this.search=response);
       }
       else if(this.role ==null)
       {
         this.filterService.getFilterDataByLocation(this.location).subscribe(response => this.search=response);
       }
       else
       {
        this.filterService.getFilterDataByRole(this.role).subscribe(response => this.search=response);

       }
       
      
    
    }

    openVendor(email,role)
    {
      console.log("****************"+role);
      if(role =="Halls")
      {
        this.hideVendorProfile = false;
        this.display = true;
        this.hallService.getHallInfo(email).subscribe(vendorData => this.hallInfo = vendorData);

       }
    }
    openBooking(vendorEmail,vendorRole)
    {
         this.bookFormOpen = true;
         this.bookFormClose =false;
         this.vendorEmail = vendorEmail;
         this.vendorRole = vendorRole;
         

    }
    bookVendor()
    {
       this.cont = false;
       this.success = true;
       let bookingData = new Booking(this.email,this.vendorEmail,this.date,"processing");
       this.userService.bookVendor(bookingData).subscribe(response => console.log(response));
       console.log(bookingData.bookingDate);
    }
   
}
