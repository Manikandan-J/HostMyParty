import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Model/User';
import { UserService } from 'src/app/Service/user.service';
import { Router } from '@angular/router';
import { Search } from 'src/app/Model/Search';
import { SearchServiceService } from 'src/app/Service/search-service.service';
import { LoginServicesService } from 'src/app/Service/login-services.service';
import { Login } from 'src/app/Model/Login';

@Component({
  selector: 'app-register-profile',
  templateUrl: './register-profile.component.html',
  styleUrls: ['./register-profile.component.css']
})
export class RegisterProfileComponent implements OnInit {

  email: string;
  name: string;
  gender: string;
  role: string;
  password: string;
  address: string;
  city: string;
  number: string;
  cont: boolean= true;
  success: boolean= false;
  login: Login[];
  invalidEmail: boolean = false;
  constructor(private userService: UserService,private router: Router,private searchService: SearchServiceService,private loginService: LoginServicesService) { }

  ngOnInit(): void {

  }
  onSubmit() {
   
        this.registerProfile();
     
  }
  registerProfile()
  {
    this.cont =false;
    this.success =true;
    let user = new User(this.email,this.name,this.gender,this.role,this.password,this.address,this.city,this.number);
    this.userService.registerUser(user).subscribe(response => console.log(response)); 
    if(this.role ! = "User")
    {
    let search = new Search(this.email,this.role,this.city,"active");
    this.searchService.updateSearch(search).subscribe(response =>console.log(response));
    }
   

  }

}
