import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/Service/notification.service';
import { UserService } from 'src/app/Service/user.service';
import { Booking } from 'src/app/Model/Booking';
import { Observable, of } from 'rxjs';
import { ModelBooking } from 'src/app/Model/ModelBooking';
import { DataService } from 'src/app/Service/data.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  bookingData: Booking[];

  email: string;
  role: string;
  showRecord: boolean =false;
  data: boolean = false;
  constructor(private router: Router,private vendorService: NotificationService,private userService: UserService,private dataService: DataService) { }
   
  ngOnInit(): void {
    this.dataService.currentUserEmail.subscribe(email => this.email = email);
    this.dataService.currentRole.subscribe(role => this.role =role);
    if(this.role !="User")
    {
      this.data = true;
    }
    this.userService.getAllBookingRecords().subscribe(response => this.bookingData=response);
      
     
  }
  acceptProposal(id,userEmail,vendorEmail,dateOfBooking)
  {
    console.log("Booked");
    let newBookData = new ModelBooking(id,userEmail,vendorEmail,dateOfBooking,"Booked");
    
    this.vendorService.updateBooking(newBookData).subscribe(response =>console.log(response));

  }
  rejectProposal(id,userEmail,vendorEmail,dateOfBooking)
  {
    console.log("rejeceted");
    let newBookData = new  ModelBooking(id,userEmail,vendorEmail,dateOfBooking,"Rejected");
  this.vendorService.updateBooking(newBookData).subscribe(response => console.log(response));
  }
 
}
