import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RandomPartiesComponent } from './random-parties.component';

describe('RandomPartiesComponent', () => {
  let component: RandomPartiesComponent;
  let fixture: ComponentFixture<RandomPartiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RandomPartiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RandomPartiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
