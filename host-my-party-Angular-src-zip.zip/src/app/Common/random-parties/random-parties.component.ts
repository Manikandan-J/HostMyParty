import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-random-parties',
  templateUrl: './random-parties.component.html',
  styleUrls: ['./random-parties.component.css']
})
export class RandomPartiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
