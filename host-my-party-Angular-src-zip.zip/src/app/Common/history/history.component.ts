import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/Service/user.service';
import { Router } from '@angular/router';
import { Booking } from 'src/app/Model/Booking';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {

  bookingData: Booking[];

  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
    
  this.userService.getAllBookingRecords().subscribe(response => this.bookingData=response);

  }

}
