import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { MainTemplateComponent } from './main-template/main-template.component';
import { RandomPartiesComponent } from './Common/random-parties/random-parties.component';
import { RegisterProfileComponent } from './Common/register-profile/register-profile.component';
import { VendorServiceComponent } from './Vendor/vendor-service/vendor-service.component';
import { UpdateHallInfoComponent } from './Vendor/UpdateVendorInfo/update-hall-info/update-hall-info.component';
import { UpdateStatusComponent } from './Common/update-status/update-status.component';
import { SearchComponent } from './Common/search/search.component';
import { NotificationComponent } from './Common/notification/notification.component';
import { HistoryComponent } from './Common/history/history.component';
import { WalletComponent } from './Common/wallet/wallet.component';


const routes: Routes = [
  { path: '', redirectTo: '/Login', pathMatch: 'full' },
  { path: 'Login', component: LoginPageComponent },
  { path: 'RegisterYourAccount', component: RegisterProfileComponent },
  {path:'MainAction',component: MainTemplateComponent,
  children:[
    {path:'',component: RandomPartiesComponent},
    {path:'RandomParties',component: RandomPartiesComponent},
    {path:'SearchVendors',component:SearchComponent},
    {path:'Notification',component:NotificationComponent},
    {path:'History',component:HistoryComponent},
    {path:'MyWallet',component:WalletComponent},

    {path:'VendorServices',component: VendorServiceComponent,
       children:[
        {path: 'UpdateHallInfo',component: UpdateHallInfoComponent},
        {path: 'UpdateStatus',component: UpdateStatusComponent}
       ]
  },
    
    
  ]
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  
 }
