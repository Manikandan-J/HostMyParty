package com.hostmyparty;

import java.util.stream.Stream;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.hostmyparty.entityLayer.LoginTable;
import com.hostmyparty.repositoryLayer.LoginRepository;

@SpringBootApplication
public class HostmypartyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostmypartyApplication.class, args);
	}
		@Bean
		ApplicationRunner init(LoginRepository loginrepo)
		{
			return args -> {
				Stream.of(new LoginTable("user@gmail.com","user","User"))
				.forEach(user -> {
					loginrepo.save(user);
				});
				
			};
	
	}
}


