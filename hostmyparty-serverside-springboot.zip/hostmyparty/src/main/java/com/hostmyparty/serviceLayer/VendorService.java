package com.hostmyparty.serviceLayer;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.HallInfoTable;
import com.hostmyparty.entityLayer.SearchTable;
import com.hostmyparty.interfaceLayer.VendorServiceInterface;
import com.hostmyparty.repositoryLayer.BookingTableRepository;
import com.hostmyparty.repositoryLayer.HallInfoRepsository;
import com.hostmyparty.repositoryLayer.SearchRepository;
@Component
@Service
public class VendorService implements VendorServiceInterface {
 @Autowired
 HallInfoRepsository hallInfoRepo;
 @Autowired
 SearchRepository searchRepo;
 @Autowired
 BookingTableRepository bookRepo;
	@Override
	public Optional<HallInfoTable> getHallInfo(String email) {
		// TODO Auto-generated method stub
		return hallInfoRepo.findById(email);
	}
	@Override
	public void updateHallInfo(HallInfoTable hallData) {
		// TODO Auto-generated method stub
		hallInfoRepo.save(hallData);
	}
	@Override
	public void updateSearch(SearchTable searchTableData) {
		// TODO Auto-generated method stub
		searchRepo.save(searchTableData);
		
	}
	@Override
	public Optional<SearchTable> getAllSearchData(String email) {
		// TODO Auto-generated method stub
		return searchRepo.findById(email);
	}
	@Override
	public List<SearchTable> getFilterData(String role, String location) {
		// TODO Auto-generated method stub
		
			System.out.println("hello");
			return searchRepo.getFilterData(role,location);
			
		
	}
	@Override
	public List<SearchTable> getFilterDataByLocation(String location) {
		// TODO Auto-generated method stub
		return searchRepo.getFilterDataByLocation(location);
	}
	@Override
	public List<SearchTable> getFilterDataByRole(String role) {
		// TODO Auto-generated method stub
		return searchRepo.getFilterDataByRole(role);
	}
	@Override
	public void updateBookingTable(BookingTable bookingTableData) {
	
		   bookRepo.save(bookingTableData);
	}

}
