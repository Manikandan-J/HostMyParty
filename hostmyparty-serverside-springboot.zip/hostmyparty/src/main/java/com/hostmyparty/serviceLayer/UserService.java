package com.hostmyparty.serviceLayer;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.UserTable;
import com.hostmyparty.entityLayer.WalletTable;
import com.hostmyparty.interfaceLayer.UserInterface;
import com.hostmyparty.repositoryLayer.BookingTableRepository;
import com.hostmyparty.repositoryLayer.UserRepository;
import com.hostmyparty.repositoryLayer.WalletRepository;

@Component
@Service
public class UserService implements UserInterface {

	@Autowired
	UserRepository userRepo;
    
	@Autowired
	BookingTableRepository bookRepo;
	
	@Autowired
	WalletRepository walletRepo;
	@Override
	public Optional<UserTable> getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepo.findById(email);
	}

	@Override
	public void registerNewUser(UserTable userData) {
		// TODO Auto-generated method stub
		userRepo.save(userData);
	}

	@Override
	public void bookVendor(BookingTable bookingData) {
		
      bookRepo.save(bookingData);
	}

	@Override
	public List<BookingTable> getAllBookingRecords() {
		return bookRepo.findAll();
		
	}

	@Override
	public void addWallet(WalletTable walletData) {
		// TODO Auto-generated method stub
		walletRepo.save(walletData);
	}
}
