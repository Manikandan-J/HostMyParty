package com.hostmyparty.serviceLayer;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.LoginTable;
import com.hostmyparty.entityLayer.UserTable;
import com.hostmyparty.interfaceLayer.LoginInterface;
import com.hostmyparty.repositoryLayer.LoginRepository;

@Component
@Service
public class LoginService implements LoginInterface {
@Autowired
LoginRepository loginRepo;
	@Override
	public List<LoginTable> getAllCredentials() {
		// TODO Auto-generated method stub
		
		return loginRepo.findAll();
	}
	@Override
	public void addNewCredential(UserTable userData) {
		// TODO Auto-generated method stub
		loginRepo.save(new LoginTable(userData.getEmail(),userData.getPassword(),userData.getRole()));
	}

	  
}
