package com.hostmyparty.repositoryLayer;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hostmyparty.entityLayer.SearchTable;

@Repository
public interface SearchRepository  extends JpaRepository<SearchTable,String>{
 
   @Query(nativeQuery=true,value="Select * from SearchTable  where role =:role and location =:location")
	List<SearchTable> getFilterData(String role, String location);

	@Query(nativeQuery=true,value="Select * from SearchTable  where location =:location")
    List<SearchTable> getFilterDataByLocation(String location);

	@Query(nativeQuery=true,value="Select * from SearchTable  where role =:role")
    List<SearchTable> getFilterDataByRole(String role);

}
