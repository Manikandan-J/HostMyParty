package com.hostmyparty.repositoryLayer;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hostmyparty.entityLayer.HallInfoTable;

public interface HallInfoRepsository extends JpaRepository<HallInfoTable,String> {

}
