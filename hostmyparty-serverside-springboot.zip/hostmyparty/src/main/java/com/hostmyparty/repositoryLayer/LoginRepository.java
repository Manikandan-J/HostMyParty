package com.hostmyparty.repositoryLayer;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hostmyparty.entityLayer.LoginTable;

public interface LoginRepository extends JpaRepository<LoginTable,String>{

}
