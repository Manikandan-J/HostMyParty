package com.hostmyparty.repositoryLayer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hostmyparty.entityLayer.BookingTable;

@Repository
public interface BookingTableRepository extends JpaRepository<BookingTable,String> {

     

}
