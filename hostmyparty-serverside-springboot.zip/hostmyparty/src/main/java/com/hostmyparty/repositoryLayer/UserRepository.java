package com.hostmyparty.repositoryLayer;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hostmyparty.entityLayer.UserTable;

public interface UserRepository extends JpaRepository<UserTable,String>{

}
