package com.hostmyparty.entityLayer;

public class EventManagerInfoTable {

}
