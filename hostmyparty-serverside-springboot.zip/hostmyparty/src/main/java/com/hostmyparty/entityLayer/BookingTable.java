package com.hostmyparty.entityLayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "booking_table")
public class BookingTable {

	@Column(name="booking_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bookingId;
	@Column(name = "user_email")
    private String userEmail;
	@Column(name = "vendor_email")
    private String vendorEmail;
	@Column(name = "date_of_booking")
    private String  bookingDate;
	@Column(name = "booking_status")
    private String bookingStatus;
	public long getBookingId() {
		return bookingId;
	}
	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getVendorEmail() {
		return vendorEmail;
	}
	public void setVendorEmail(String vendorEmail) {
		this.vendorEmail = vendorEmail;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public BookingTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingTable(long bookingId, String userEmail, String vendorEmail, String bookingDate,
			String bookingStatus) {
		super();
		this.bookingId = bookingId;
		this.userEmail = userEmail;
		this.vendorEmail = vendorEmail;
		this.bookingDate = bookingDate;
		this.bookingStatus = bookingStatus;
	}
	@Override
	public String toString() {
		return "BookingTable [bookingId=" + bookingId + ", userEmail=" + userEmail + ", vendorEmail=" + vendorEmail
				+ ", bookingDate=" + bookingDate + ", bookingStatus=" + bookingStatus + "]";
	}
	
}
