package com.hostmyparty.entityLayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hall_info_table")
public class HallInfoTable {

	@Id
    @Column(name = "email")
    private String email;
	@Column(name = "hall_name",nullable = false)
    private String hallName;
	@Column(name = "hall_role",nullable = false)
    private String hallRole;
	@Column(name = "no_of_floor",nullable = false)
    private int noOfFloor;
	@Column(name = "dimension",nullable = false)
    private String dimension;
	@Column(name = "people_count",nullable = false)
    private int peopleCount;
	@Column(name = "dinning_style",nullable = false)
    private String dinningStyle;
	@Column(name = "rate_per_hour",nullable = false)
    private int ratePerHour;
	@Column(name = "main_location",nullable = false)
    private String location;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getHallName() {
		return hallName;
	}
	public void setHallName(String hallName) {
		this.hallName = hallName;
	}
	public String getHallRole() {
		return hallRole;
	}
	public void setHallRole(String hallRole) {
		this.hallRole = hallRole;
	}
	public int getNoOfFloor() {
		return noOfFloor;
	}
	public void setNoOfFloor(int noOfFloor) {
		this.noOfFloor = noOfFloor;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public int getPeopleCount() {
		return peopleCount;
	}
	public void setPeopleCount(int peopleCount) {
		this.peopleCount = peopleCount;
	}
	public String getDinningStyle() {
		return dinningStyle;
	}
	public void setDinningStyle(String dinningStyle) {
		this.dinningStyle = dinningStyle;
	}
	public int getRatePerHour() {
		return ratePerHour;
	}
	public void setRatePerHour(int ratePerHour) {
		this.ratePerHour = ratePerHour;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public HallInfoTable(String email, String hallName, String hallRole, int noOfFloor, String dimension,
			int peopleCount, String dinningStyle, int ratePerHour, String location) {
		super();
		this.email = email;
		this.hallName = hallName;
		this.hallRole = hallRole;
		this.noOfFloor = noOfFloor;
		this.dimension = dimension;
		this.peopleCount = peopleCount;
		this.dinningStyle = dinningStyle;
		this.ratePerHour = ratePerHour;
		this.location = location;
	}
	public HallInfoTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "HallInfoTable [email=" + email + ", hallName=" + hallName + ", hallRole=" + hallRole + ", noOfFloor="
				+ noOfFloor + ", dimension=" + dimension + ", peopleCount=" + peopleCount + ", dinningStyle="
				+ dinningStyle + ", ratePerHour=" + ratePerHour + ", location=" + location + "]";
	}
	
	
	
	
	
}
