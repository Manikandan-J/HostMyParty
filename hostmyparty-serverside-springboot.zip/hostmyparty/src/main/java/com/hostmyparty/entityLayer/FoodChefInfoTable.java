package com.hostmyparty.entityLayer;

public class FoodChefInfoTable {

}
