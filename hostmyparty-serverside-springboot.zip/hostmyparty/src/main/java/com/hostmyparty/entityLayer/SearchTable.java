package com.hostmyparty.entityLayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "searchtable")
public class SearchTable {
	
	@Id
    @Column(name = "email")
    private String email;
	@Column(name = "role")
    private String role;
	@Column(name = "location")
    private String location;
	@Column(name = "status")
    private String status;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public SearchTable(String email, String role, String location, String status) {
		super();
		this.email = email;
		this.role = role;
		this.location = location;
		this.status = status;
	}
	public SearchTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SearchTable [email=" + email + ", role=" + role + ", location=" + location + ", status=" + status + "]";
	}
	
  

}
