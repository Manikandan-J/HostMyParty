package com.hostmyparty.entityLayer;

public class PhotoVideoGraphyInfoTable {

}
