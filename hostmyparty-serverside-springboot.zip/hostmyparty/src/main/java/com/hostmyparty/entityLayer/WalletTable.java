package com.hostmyparty.entityLayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "wallet_table")
public class WalletTable {

	@Id
    @Column(name = "email")
    private String email;
	@Column(name = "amount")
    private String amount;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public WalletTable(String email, String amount) {
		super();
		this.email = email;
		this.amount = amount;
	}
	public WalletTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "WalletTable [email=" + email + ", amount=" + amount + "]";
	}
	
}
