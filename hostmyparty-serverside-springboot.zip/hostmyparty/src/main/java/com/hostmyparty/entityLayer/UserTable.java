package com.hostmyparty.entityLayer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_table")
public class UserTable {

	@Id
    @Column(name = "email")
    private String email;
	
	@Column(name = "name",nullable = false)
    private String name;
	@Column(name = "gender")
    private String gender;
	@Column(name = "role",nullable = false)
    private String role;
	@Column(name = "password",nullable = false)
    private String password;
	@Column(name = "address",nullable = false)
    private String address;
	@Column(name = "city",nullable = false)
    private String city;
	@Column(name = "contact_no")
    private String number;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public UserTable(String email, String name, String gender, String role, String password, String address,
			String city, String number) {
		super();
		this.email = email;
		this.name = name;
		this.gender = gender;
		this.role = role;
		this.password = password;
		this.address = address;
		this.city = city;
		this.number = number;
	}
	public UserTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserTable [email=" + email + ", name=" + name + ", gender=" + gender + ", role=" + role + ", password="
				+ password + ", address=" + address + ", city=" + city + ", number=" + number + "]";
	}
	
	
}
