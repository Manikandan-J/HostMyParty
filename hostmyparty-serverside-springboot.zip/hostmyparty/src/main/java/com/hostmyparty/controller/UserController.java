package com.hostmyparty.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.UserTable;
import com.hostmyparty.entityLayer.WalletTable;
import com.hostmyparty.interfaceLayer.LoginInterface;
import com.hostmyparty.interfaceLayer.UserInterface;


@CrossOrigin(origins = "http://localhost:4200")
@RestController 
@RequestMapping("/user")
public class UserController {

	@Autowired
	 UserInterface userInterface;
	@Autowired
	LoginInterface loginInterface;
	@GetMapping(value = "/getByEmail/{email}")
	public Optional<UserTable> getUserByEmail(@PathVariable String email) {

		return userInterface.getUserByEmail(email);
	}
	@PostMapping("/registerProfile")
	public void registerProfile(@RequestBody UserTable userData)
	{
		loginInterface.addNewCredential(userData);
		userInterface.registerNewUser(userData);
	}
	@PostMapping("/bookVendor")
	public void bookVendor(@RequestBody BookingTable bookingData)
	{
		
		userInterface.bookVendor(bookingData);
	}
	@PostMapping("/addAmount")
	public void addWallet(@RequestBody WalletTable walletData)
	{
		
		userInterface.addWallet(walletData);
	}
	@GetMapping("/getAllBookingRecords")
	public List<BookingTable> getAllBookingRecords()
	{
		return userInterface.getAllBookingRecords();
	}
}
