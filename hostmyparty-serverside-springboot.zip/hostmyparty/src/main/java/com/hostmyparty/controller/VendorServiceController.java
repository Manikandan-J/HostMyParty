package com.hostmyparty.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.HallInfoTable;
import com.hostmyparty.entityLayer.SearchTable;
import com.hostmyparty.entityLayer.UserTable;
import com.hostmyparty.interfaceLayer.VendorServiceInterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController 
@RequestMapping("/VendorsInfo")
public class VendorServiceController {
	@Autowired
	VendorServiceInterface vendorInterface;
	
	@GetMapping(value = "/getHallInfo/{email}")
	public Optional<HallInfoTable> getHallInfo(@PathVariable String email) {

		return vendorInterface.getHallInfo(email);
	}
   
	@PostMapping("/updateHallInfo")
	public void updateHallInfo(@RequestBody HallInfoTable hallData)
	{
		vendorInterface.updateHallInfo(hallData);
		
	}
	@PostMapping("/updateSearch")
	public void updateSearch(@RequestBody SearchTable searchTableData)
	{
		vendorInterface.updateSearch(searchTableData);
		
	}
	@PostMapping("/updateBookingTable")
	public void updateBookingTable(@RequestBody BookingTable bookingTableData)
	{
		
		vendorInterface.updateBookingTable(bookingTableData);
		
	}
	@GetMapping(value = "/getAllSearchData/{email}")
	public Optional<SearchTable> getAllSearchData(@PathVariable String email) {

		return vendorInterface.getAllSearchData(email);
	}
	
	@GetMapping(value = "/getFilterData/{role}/{location}")
	public List<SearchTable> getFilterData(@PathVariable("role") String role,@PathVariable("location") String location) {
         
		
		return vendorInterface.getFilterData(role,location);
		
	}
	
	@GetMapping(value = "/getFilterDataByLocation/{location}")
	public List<SearchTable> getFilterDataByLocation(@PathVariable("location") String location) {
         
		
			return vendorInterface.getFilterDataByLocation(location);

		
	}
	@GetMapping(value = "/getFilterDataByRole/{role}")
	public List<SearchTable> getFilterDataByRole(@PathVariable("role") String role) {
         
		
		
			return vendorInterface.getFilterDataByRole(role);

		
	}
	@GetMapping(value = "/mani/{role}")
	public List<SearchTable> getFilterDataByMani(@PathVariable("role") String role) {
         
		
		
			return vendorInterface.getFilterDataByRole(role);

		
	}
	
	
}
