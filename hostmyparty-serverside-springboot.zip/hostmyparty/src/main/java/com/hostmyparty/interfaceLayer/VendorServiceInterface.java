package com.hostmyparty.interfaceLayer;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.HallInfoTable;
import com.hostmyparty.entityLayer.SearchTable;

@Service
public interface VendorServiceInterface {

	Optional<HallInfoTable> getHallInfo(String email);

	void updateHallInfo(HallInfoTable hallData);

	void updateSearch(SearchTable searchTableData);

	Optional<SearchTable> getAllSearchData(String email);

	List<SearchTable> getFilterData(String role, String location);

	List<SearchTable> getFilterDataByLocation(String location);

	List<SearchTable> getFilterDataByRole(String role);

	void updateBookingTable(BookingTable bookingTableData);

}
