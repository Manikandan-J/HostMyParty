package com.hostmyparty.interfaceLayer;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.BookingTable;
import com.hostmyparty.entityLayer.UserTable;
import com.hostmyparty.entityLayer.WalletTable;

@Service
public interface UserInterface {

  public Optional<UserTable> getUserByEmail(String email);

public void registerNewUser(UserTable userData);

public void bookVendor(BookingTable bookingData);

public List<BookingTable> getAllBookingRecords();

public void addWallet(WalletTable walletData);

}
