package com.hostmyparty.interfaceLayer;
import java.util.List;

import org.springframework.stereotype.Service;

import com.hostmyparty.entityLayer.LoginTable;
import com.hostmyparty.entityLayer.UserTable;

@Service
public interface LoginInterface {

	 public List<LoginTable> getAllCredentials();

	public void addNewCredential(UserTable userData);
}
